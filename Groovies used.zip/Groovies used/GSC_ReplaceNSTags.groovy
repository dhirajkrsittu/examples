import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // Retrieve the body of the message as a string
    def body = message.getBody(String.class);
    
    // Replace 'OldValue' with 'NewValue'
    body = body.replaceAll("p5:EmployeeNr", "EmployeeNr");
    body = body.replaceAll("p5:MessageHeader", "MessageHeader");
    
    // Set the modified body back into the message
    message.setBody(body);
    
    return message;
}
