import com.sap.it.api.ITApi
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.*
import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

// Define the custom data processing logic for the integration flow

def Message processData(Message message) {

   def body = message.getBody();
   String password;
   String username;

   // Access the Secure Store service through the ITApiFactory
   def service = ITApiFactory.getApi(SecureStoreService.class, null);

   // Retrieve the user credential using the alias "ABT_CI_056" from the Security Material
   def credential = service.getUserCredential("GUNL_PROC_FIELDGLASS_PASS");

   // Check if the credential was found in the Secure Store
   if (credential == null) {
       throw new IllegalStateException("No credential found for alias 'GUNL_PROC_FIELDGLASS_PASS'");
   } else {
       // If the credential is found, extract the username and password from it
       password = new String(credential.getPassword());
   }

   message.setProperty("PASSWORD", password);
 //  message.setProperty("USERNAME", username);
   return message;

}