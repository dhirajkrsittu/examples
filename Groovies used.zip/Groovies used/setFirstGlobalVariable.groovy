/*
Author: Sonali Prakash
Date: 07-Dec-2023
Version: 1.0

This groovy is to check if the LastExecutionDate is empty. For the first time run in any other environment when the Global variable is empty.
*/


import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;

def Message setFirstGlobalVariable(Message message) {

    String lastexectime = message.getProperties().get("LastExecutionDate");
    
    if (lastexectime == null || lastexectime.isEmpty()) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -7);
        Date date = cal.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String newDate = format.format(date);
        //message.setBody(newDate);
        message.setProperty("LastExecutionDate",newDate);
        //message.setProperty("LastExecutionDate","2023-02-21T00:00:00");

    }
    
    return message;
}