import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
//import java.util.Hashmap;
import com.sap.it.api.mapping.MappingContext

def String getPropertyLongtext(String setLongtext, MappingContext context)
{
	def propValue = context.getProperty(setLongtext)
	
	return propValue; 
}