/*
Author: Sonali Prakash
Date: 07-Dec-2023
Version: 1.0
*/

import com.sap.gateway.ip.core.customdev.util.Message;
//import groovy.util.XmlSlurper;
import java.util.HashMap;

def Message processData(Message message) {
    //Body
    def inputXml = message.getBody(java.lang.String) as String;
    def result = inputXml.replaceAll('&quot;', '"')
    message.setBody(result);
    
    return message;
}