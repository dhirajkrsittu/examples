/*
Author: Sonali Prakash
Date: 09-Sept-2023
Version: 1.0

This groovy is to remove the root nodes in from xml to json
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import groovy.json.JsonBuilder;

def Message processData(Message message) {

    def body = message.getBody(String);
    def map = new JsonSlurper();
    def object = map.parseText(body)
    def builder = new JsonBuilder(object.ZRV_AM_INBD_ALARM_INTF_NOTIF.ZRV_AM_INBD_ALARM_INTF_NOTIFType)

    message.setBody(builder.toString())
    return message;

}