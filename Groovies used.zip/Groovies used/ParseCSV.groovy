/*
Author: Sonali Prakash
Date: 07-Dec-2023
Version: 1.0

This groovy is to convert CSV data into desired format ("" double quotes added in every value except PERNR)
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body
    def body = message.getBody(java.lang.String) as String;
    String[] contentArr = body.split("\n"); 
    int length = contentArr.length;
    StringBuilder resultBuilder = new StringBuilder();
    resultBuilder.append(String.format("%s\n",contentArr[0])); //adding the Header line in the resultSet
    
    for (int i=1; i<length; i++) //i=1 because for i=0 is the headers line
    {
        String line = contentArr[i];
        String[] lineArray = line.split(",");
        resultBuilder.append(String.format("%s,",lineArray[0])); //adding the PERNR field in the resultSet because no quotes needed for that
        int lineLength = lineArray.length;
        for (int j=1; j<lineLength; j++) //j=1 because for j=0 is the PERNR which doesn't need quotes
        {
            if(j<lineLength-1)
            {
                resultBuilder.append(String.format("\"%s\",",lineArray[j])); // \ because escape character
            }
            else{
                String newValue = lineArray[j].substring(0,lineArray[j].length()-1)
                resultBuilder.append(String.format("\"%s\"",newValue)); // \ because escape character

            }
        }
        resultBuilder.append("\n");
    }
    message.setBody(resultBuilder.toString());
    
    return message;
}