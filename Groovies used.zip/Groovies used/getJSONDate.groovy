def long convertDateToEpoch(String xmlDate){
    String inputDateFormat = "yyyy-MM-dd";
    // String inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss";
    try {
      // Create a DateTime Formatter based on the input datetime format
      SimpleDateFormat sdf = new SimpleDateFormat(inputDateFormat);
      sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
      Date parsedDate = sdf.parse(xmlDate);   // Parse the input date string into a LocalDateTime object
      long epochDate = parsedDate.getTime();  // Convert the LocalDateTime to epoch time (seconds since January 1, 1970)
      return epochDate;
    }
    catch (Exception e) {
      return 0;
    }
}