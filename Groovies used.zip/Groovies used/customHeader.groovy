import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
 
def Message processData(Message message) {
    def body = message.getBody(String)
    // Strip XML declaration if present
    if (body.startsWith("<?xml")) {
        body = body.substring(body.indexOf("?>") + 2).trim()
    }
    def xml = new XmlSlurper().parseText(body)
    def messages = xml.'**'.findAll { it.name() == 'message' }.collect { it.text() }
    // Sanitize the messages to remove or escape special characters
    def sanitizedMessages = messages.collect { it.replaceAll(/[><]/, '') }
    // sanitizedMessages.each { println it }
    message.setProperty("ODataErrorBody", sanitizedMessages.toSet()[0])
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        def properties = message.getProperties();
        def documentId = properties.get("documentId");
        def Material = properties.get("Material");
        def ManufacturingOrder = properties.get("ManufacturingOrder");
	    messageLog.addCustomHeaderProperty("documentId", documentId);	
	    messageLog.addCustomHeaderProperty("Material", Material);
	    messageLog.addCustomHeaderProperty("ManufacturingOrder", ManufacturingOrder);
	    if(ManufacturingOrder == null)
	    {
	        messageLog.addCustomHeaderProperty("Summary", "No Released Order Present in S4");
	    }
    }
    return message
}