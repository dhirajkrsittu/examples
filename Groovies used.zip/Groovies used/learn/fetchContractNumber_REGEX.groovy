import com.sap.it.api.mapping.MappingContext;

//New code logic for contract no. as per RAIL 28903|I1298077
def String fetchContractNumber(String contractNumberString,MappingContext context) {
    def contractNumber = ""   
    
    if (contractNumberString == null || contractNumberString.isEmpty())	{
      return contractNumber
    }
    def matcher = contractNumberString =~ /(?i)Contract no - (\d+) - Do Not Delete/   
	//creates a matcher object by applying the regular expression to the input string. // (?i) means its case insensitive  , (\d+) means indefinite leght of integers , its a partial match
    contractNumber = matcher ? matcher[0][1] : ''   
	//If there is a match: matcher[0][1] accesses the first match's first capturing group, which is the number between the hyphens.
    return contractNumber
}

// for exact match contractNumberString =~ /^(?i)Contract no - (\d+) - Do Not Delete$/

/*

    //contractNumberString = "abcd- ContRaCt no - 121  - Do Not Delete "  --> o/p = 121  only valid case.
	//contractNumberString = "contract" --> o/p = return empty string
	//Contract No - 234 - TestAbcd ---> empty contract no.
	//Contract no - 345 - TestABCD - Do Not Delete ---> empty contract no.  

*/

//----------------------------------------------------------------------------------------------------------

/*Script as per the Go-live version 1.1.0 */
/*import com.sap.it.api.mapping.*;
def String fetchContractNumber(String contractNumberString,MappingContext context){
    def contractNumber = ""    
    
	if (contractNumberString == null || contractNumberString.isEmpty()){
      contractNumber =""

    }
    def splitValues = contractNumberString.split('-')
    contractNumber = splitValues.size() > 1 ? splitValues[1] : ""
	
	return contractNumber
}
*/
