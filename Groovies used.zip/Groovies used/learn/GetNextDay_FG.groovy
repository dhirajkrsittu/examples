/*
Author: Sonali Prakash
Date: 05-April-2024
Version: 1.0

This groovy is to fetch the date after X number of days from the incoming date.  BASIC ISO Date format (java std) = YYYYMMDD coming from S4.

*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.time.LocalDate
import java.time.format.DateTimeFormatter


def Message processData(Message message)
{
    
    String inputDate = (String) message.getProperty("AdhocApprovalDate")
    LocalDate date = LocalDate.parse(inputDate, DateTimeFormatter.BASIC_ISO_DATE) 
	
    LocalDate nextDay = date.plusDays(1);
    String result = nextDay.format(DateTimeFormatter.BASIC_ISO_DATE)
    message.setProperty("AdhocRunDate", result);

    return message;
}
