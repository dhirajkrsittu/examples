import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;

def Message processData(Message message) {

    def xmlPayload = message.getBody(java.lang.String)
    def xmlText = new XmlSlurper().parseText(xmlPayload)
    //error/message
    
    def textContent = xmlText.message.text()

    message.setProperty("errorMessage", textContent);
    //message.setBody(textContent.toString())

    return message
}
