/*
Author: Sonali Prakash
Date: 09-Sept-2023
Version: 1.0

This groovy is to fetch the Date and Time in the required API format
*/

import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;

//this function is to add "/Date(" in date format
def String getAPIReqDate(String inputDate){
    String input = getInputTimestamp(inputDate)
    String epoch = getEpochTimeInMillis(input) //calling internal method to get time in Epoch
    String res = sprintf("/Date(%s)/",epoch) 
    return (res);
}

//This function is to fetch the Time in the required API format
def String getAPIReqTime(String inputDate){
    try {
        String xmlTime = getInputTimestamp(inputDate)
        String[] array = xmlTime.split('T');
        String time = array[1];
        String[] timeArray = time.split(':');
        def result = sprintf("PT%sH%sM%sS",timeArray[0],timeArray[1],timeArray[2])   // as string
        return(result)
    }
    catch (Exception e) {
        return(e.message)
    }
}

/***********************************************************************/

//this function is to get correct date based on the original input format
def String getInputTimestamp(String inputDate){
    if (inputDate.contains("+")) {
        String finalInput = convertTimeWithOffset(inputDate)
        return(finalInput)
    } else {
        return(inputDate)
    }
}


def String getEpochTimeInMillis(String inputDate){
    // Define the date format of your input date
    String inputDateFormat = "yyyy-MM-dd"
    try {
        // Create a DateTimeFormatter based on the input date format
        SimpleDateFormat sdf = new SimpleDateFormat(inputDateFormat)
        sdf.setTimeZone(TimeZone.getTimeZone("CET")) 
        Date inputDate = sdf.parse(inputDate)   // Parse the input date string into a LocalDateTime object
        long epochDate = inputDate.getTime()  // Convert the LocalDateTime to epoch time (seconds since January 1, 1970)
        return(epochDate)
    }
    catch (Exception e) {
        return(e.message)
    }
}

/*****************************************************/


//This function is to fetch the Time in the CET timezone API format

def String convertTimeWithOffset(String inputDateWithOffset){
    try {
        String inputTime = inputDateWithOffset.replace("T", " ") //some issues was coming while converting date with T, so we replaced it with space.
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        Date date = sdf.parse(inputTime)
        long epoch = date.getTime()  //utc time here

        String[] array = inputDateWithOffset.split("\\+") // ["2023-09-08T15:23:34", "2:00"]
        String timeDiff = array[1] // 02:00
        String[] timeDiffArr = timeDiff.split(":") // ["02", "00"]
        int diffHour = timeDiffArr[0].toInteger() // 2
        int diffMin = timeDiffArr[1].toInteger() // 0
        long diff = ((diffHour * 60) + diffMin) * 60 * 1000 // conversion to milliseconds

        long newEpochTime = epoch + diff
        Date newDate = new Date(newEpochTime) // creating new date object with new epoch time
        String newTS = sdf.format(newDate)
        String finalRes = newTS.replace(" ", "T");
       // println(finalRes)
        return(finalRes)
    }
    catch (Exception e) {
        return(e.message)
    }
}