import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def map = message.getProperties();
    def MaterialName = map.get("MaterialName");
    
    if (MaterialName != null && MaterialName.toLowerCase().contains("bulk")) 
    {
        message.setProperty("ScheduleFloatProfile", "ZBULK"); // set property if bulk is present
    }
    else {
        message.setProperty("ScheduleFloatProfile", "ZPACK"); // set property if bulk is absent
    }
  return message;
}
