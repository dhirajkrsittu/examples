/*
Author: Sonali Prakash
Date: 09-Sept-2023 // 14=Mar-2024
Version: 1.0/ v1.1

This groovy is to convert the Date and Time from CET to UTC
*/

import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Date;



//this function is to add "/Date(" in date format
def String getAPIReqDate(String inputDate){  // sample value of inputDate: 2024-03-02T11:30:55 (CET)

    String[] array = inputDate.split("T");
    // we get epoch by converting only date part of UTC datetime to epoch
    long epoch = convertDateToEpoch(array[0]);
    String res = String.format("/Date(%d)/", epoch);
    return (res);
}

//This function is to fetch the Time in the required API format
def String getAPIReqTime(String inputDate){

      try {
//        String xmlTime = getInputTimestamp(inputDate)
        String[] arrayTemp = inputDate.split("T");
//      System.out.println(arrayTemp[1]);
        String[] array = arrayTemp[1].split("\\+");
//      System.out.println(array[0]);
        String time = array[0];
        String[] timeArray = time.split(":");
        def result = sprintf("PT%sH%sM%sS",timeArray[0],timeArray[1],timeArray[2])   // as string
        return(result)
    }
    catch (Exception e) {
      return null;
    }
}


def long convertDateToEpoch(String inputDate){
    String inputDateFormat = "yyyy-MM-dd";
    // String inputDateFormat = "yyyy-MM-dd'T'HH:mm:ss";
    try {
      // Create a DateTime Formatter based on the input datetime format
      SimpleDateFormat sdf = new SimpleDateFormat(inputDateFormat);
      sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
      Date parsedDate = sdf.parse(inputDate);   // Parse the input date string into a LocalDateTime object
      long epochDate = parsedDate.getTime();  // Convert the LocalDateTime to epoch time (milliseconds since January 1, 1970)
      return epochDate;
    }
    catch (Exception e) {
      return 0;
    }
}
/*public static void main(String[] args) {
    String timeInCET = "2024-01-17T00:40:30+02.00";
    System.out.println(getAPIReqDate(timeInCET));
    System.out.println(getAPIReqTime(timeInCET));
}



*/