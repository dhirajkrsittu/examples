/*
Author: Sonali Prakash
Date: 22-Sept-2023
Version: 1.0

This groovy is to convert the XML payload into TXT format with tab separated values.
*/

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*;

def Message convertToXML(Message msg) {
    String output = ""
    
    def xmlText = msg.getBody(java.lang.String)
    
    def materialMaster = new XmlSlurper().parseText(xmlText)
    output = output + sprintf("%s\t%s\n", materialMaster.HeaderLine.Count.text(), materialMaster.HeaderLine.CreationDate.text())

    def classLineArray = materialMaster.ClassificationLine
    int classLineLength = classLineArray.size()
	
    for (int i = 0; i < classLineLength; i++) {
        def classLine = classLineArray[i]
		
        output = output + sprintf("%s\t%s\t%s\n", classLine.objectID.text(), classLine.ClassKeywordText.text(), classLine.Class.text())

        def charLineArray = classLine.CharacteristicLine
        int charLineLength = charLineArray.size()

        for (int j = 0; j < charLineLength; j++) {
            def charLine = charLineArray[j]
            output = output + sprintf("%s\t%s\t%s\t%s\t%s\t%s\n", charLine.objectID.text(), charLine.ProductDescription.text(),
                    charLine.CharcValuePositionNumber.text(), charLine.CharcInternalID.text(),
                    charLine.CharcValueDescription.text(), charLine.CharcValue.text())
        }
    }
    
    msg.setBody(output)
    return msg
}



<ABCD> = materialMaster
  <ClassificationLine id="1"> = classLine
    <objectID>Apple</objectID>
    <ClassKeywordText>aaa</ClassKeywordText>
	<CharacteristicLine> = charLineArray
		<ProductDescription>abc</ProductDescription>
		<CharcValuePositionNumber>1</CharcValuePositionNumber>
	</CharacteristicLine>
	<CharacteristicLine> = charLineArray
		<ProductDescription>aed</ProductDescription>
		<CharcValuePositionNumber>2</CharcValuePositionNumber>
	</CharacteristicLine>
  </ClassificationLine>
  
  <ClassificationLine id="2">
    <objectID>Banana</objectID>
    <ClassKeywordText>bbb</ClassKeywordText>
  </ClassificationLine>
</ABCD>