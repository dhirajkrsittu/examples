/*
Author: Sonali Prakash
Date: 05-Sept-2023
Version: 1.0

This groovy is to fetch the current DateTime in CET(Europe/Berline) time zone and then calculate the end of next business day by adding 24hrs to it and time as 23:59:59pm.
This is required to calculte the case of emergency notification.
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import java.time.LocalDate
import java.time.LocalTime
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

def Message fetchEODnextDay (Message message)
{
 // Define the CET timezone
    ZoneId cetZone = ZoneId.of("Europe/Berlin")
    

    LocalDate currentDate = LocalDate.now(cetZone)  // Get the current date and time in CET
    LocalDate nextDay = currentDate.plusDays(1)  //  Calculate the date of the next day
    
    LocalTime endTime = LocalTime.of(23, 59, 59)  // Set the time to the end of the day (23:59:59)
    
    LocalDateTime endOfNextDay = LocalDateTime.of(nextDay, endTime)  // Combine the next day and end time to get the end of the next day

    message.setProperty("endOfNextDay", endOfNextDay);

    return message;
}
