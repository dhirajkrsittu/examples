
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

def String getOnlyNextDay() {
  String dateString = "2024-04-30T10:20:30"; // Example date in YYYYMMDD format

  // Parse the string into a LocalDate object
  LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ISO_LOCAL_DATE_TIME);

  // Add one day to the date
  LocalDate nextDay = date.plusDays(1);

  // Format the result back into the "YYYYMMDD" format
  String nextDayString = nextDay.format(DateTimeFormatter.ISO_LOCAL_DATE) + "T00:00:00";

  System.out.println("Input time: " + dateString);
  System.out.println("Output time: " + nextDayString); //2024-05-01T00:00:00
  return nextDayString;
}


def String get24HoursLater() {
  String timestamp = "2024-04-30T10:20:30"; // Example timestamp

  // Define a DateTimeFormatter with the input format
  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

  // Parse the timestamp string into a LocalDateTime object
  LocalDateTime dateTime = LocalDateTime.parse(timestamp, formatter);

  // Add 24 hours to the LocalDateTime object
  LocalDateTime nextDay = dateTime.plusHours(24);

  // Format the LocalDateTime object back into the string format
  String nextDayTimestamp = nextDay.format(formatter);

  System.out.println("Input time: " + timestamp);
  System.out.println("Output time: " + nextDayTimestamp); // 2024-05-01T10:20:30
  return nextDayTimestamp;
}
