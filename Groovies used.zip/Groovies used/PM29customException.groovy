import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;

def Message processData(Message message) {
     def body = message.getBody(java.lang.String);
       map = message.getProperties();
        def fileName = map.get("fileName");
    
   message.setProperty("ID",fileName+"_"+UUID.randomUUID());

return message;
}

