import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def String getNumberAfterComma(String str)  
{
    def value = "";
    if(str.contains(","))
    {
        String[] array = str.split(",");  // 7000,1400030
        def decimalIndex = str.indexOf(",")
        def substring = str.substring(decimalIndex + 1)
        if (substring.length() < 2)
        {
            return substring // Less than 2 digits, return what's there
        } else
        {
            str2 = substring.substring(0, 2) // Get first 2 characters == 14
        }
       
        value = array[0] + "," + str2
    }
  else{
        value = str;
  }
 
  return (value);
 
}