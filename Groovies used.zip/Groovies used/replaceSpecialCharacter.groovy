import java.util.HashMap;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.securestore.SecureStoreService;
import com.sap.it.api.securestore.AccessTokenAndUser;
import com.sap.it.api.securestore.exception.SecureStoreException;
import com.sap.it.api.ITApiFactory;
import groovy.json.JsonSlurper;
import java.lang.*
import groovy.xml.XmlUtil;
import org.apache.commons.text.StringEscapeUtils;


def Message replaceSpecialCharNew(Message message) {
    def xmlPayload = message.getBody(java.lang.String)
    def reader = new BufferedReader(new StringReader(xmlPayload))
    def line
    def original
    def output

    while ((line = reader.readLine()) != null) {
        if (line.contains("<ns1:Toelichting>")) {
            def len = line.length()
            original = line.replace("<ns1:Toelichting>", "").replace("</ns1:Toelichting>", "").trim()
            //message.setProperty("testKey",original)
            output = original.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;")
           //message.setProperty("111111",output)
            break
        }
    }

    def finalOutput = xmlPayload.replace(original, output)
    message.setBody(finalOutput);
    return message;
}
