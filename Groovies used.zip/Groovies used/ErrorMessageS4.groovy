import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.*;

def Message processData(Message message) {
    
    def properties = message.getProperties() 
    def body = properties.get("body")

    //def xmlPayload = message.getBody(java.lang.String)
    def xmlText = new XmlSlurper().parseText(body)
    //error/message
    
    def textContent = xmlText.message.text()

    message.setProperty("errorMessage", textContent);

    return message
}
