

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.net.URLEncoder;
 
def Message processData(Message message) {
   
//def value = "(FunctionalLocation='%3F0100000000000000442',ClassInternalID='209',ClassType='003')"
    
    def properties = message.getProperties() 

    def temp = properties.get("CM_FunctionalLocation")

    def temp2 = temp.replace("?","%3F");

    def temp3 = properties.get("CM_ClassInternalID")

    def temp4 = properties.get("CM_ClassType")

    def result = "(FunctionalLocation='" + temp2 + "',ClassInternalID='" + temp3 + "',ClassType='" +temp4 + "')"
    
    String encodedUrl = URLEncoder.encode(result, "UTF-8");
 
    message.setProperty("Delete_query", encodedUrl);
    return message;
    

}