/*
Author: Sonali Prakash
Date: 16-Sept-2023
Version: 1.0

This groovy is to log the payload in CPI.
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

//Logging the API response 
def Message InputPayload(Message msg) {
    //Body
    def body = msg.getBody(java.lang.String) as String;
    def msgLog = messageLogFactory.getMessageLog(msg);
    if(msgLog!=null) 
    {
       // messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        msgLog.addAttachmentAsString("InputPayload",body,"text/plain");
    }

    return msg;
}

//Post doing the mapping transformation of API response 
def Message AfterMappingPayload(Message msg) {
    //Body
    def body = msg.getBody(java.lang.String) as String;
    def msgLog = messageLogFactory.getMessageLog(msg);
    if(msgLog!=null) 
    {
       // messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        msgLog.addAttachmentAsString("AfterMappingPayload",body,"text/plain");
    }

    return msg;
}

//Post text format tab separated flatfile conversion
def Message TargetPayload(Message msg) {
    //Body
    def body = msg.getBody(java.lang.String) as String;
    def msgLog = messageLogFactory.getMessageLog(msg);
    if(msgLog!=null) 
    {
       // messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        msgLog.addAttachmentAsString("TargetPayload",body,"text/plain");
    }

    return msg;
}
