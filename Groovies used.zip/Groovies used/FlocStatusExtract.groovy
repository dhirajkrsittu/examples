/*
Author: Sonali Prakash
Date: 18-Mar-2024
Version: 1.0

This groovy is to fetch and return all the current status of the FLOC separated by comma.
*/


import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper


def Message processData(Message message) {
    //Body
    def xmlData = message.getBody();
    
    def root = new XmlSlurper().parseText(xmlData)

    def result = ""
    root.ZRV_FUNCTION_LOC_LABELSType.each { labelType ->
        result = result + "${labelType.UserStatusShortname}," // "aaa,bbb," // will also work with "${labelType.UserStatusShortname.text()},"
    }

    def finalResult = result.substring(0, result.length() - 1) //remove last comma.

 
    //def properties = message.getProperties();
    // value = properties.get("oldProperty");
    message.setProperty("result_UserStatusShortname", result);
    message.setProperty("FlocInactiveStatus", finalResult);
    // message.setProperty("newProperty", "newProperty");
    return message;
}


<ABCD>
  <ZRV_FUNCTION_LOC_LABELSType id="1">
    <name>Apple</name>
    <UserStatusShortname>aaa</UserStatusShortname>
  </ZRV_FUNCTION_LOC_LABELSType>
  <ZRV_FUNCTION_LOC_LABELSType id="2">
    <name>Banana</name>
    <UserStatusShortname>bbb</UserStatusShortname>
  </ZRV_FUNCTION_LOC_LABELSType>
</ABCD>