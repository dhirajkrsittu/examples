import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def headers = message.getHeaders();
    def properties = message.getProperties();
    def messageLog = messageLogFactory.getMessageLog(message);

    def ErrorStepID = headers.get("StandardErrorStepID");
    def ExceptionMoniter = headers.get("ExceptionCaught");
    def DataErrorTo = headers.get("DataErrorTo");
    def ConnectionErrorTo = headers.get("ConnectionErrorTo");
    def ResponseCode = headers.get("ResponseCodeHeader");
    //messageLog.addAttachmentAsString("ResponsePayload:", SoapResponse, "text/plain");
    def exceptionBody;
	
	Set<String> dataConversionExceptions = Set.of(
		"com.google.gson.stream.MalformedJsonException",
        "com.ctc.wstx.exc.WstxUnexpectedCharException",
		"com.sap.it.rt.csvtoxml.converter.exception.CsvToXmlConversionException", 
        "com.sap.it.rt.xmltocsv.converter.exception.XmlToCsvConversionException",
		"com.ctc.wstx.exc.WstxParsingException"
	);
    
    if (ErrorStepID == null) {
        return message;
    }

    def monitor = "";
    if (ExceptionMoniter != null) {
        monitor = ExceptionMoniter.getClass().getCanonicalName();
    }
    if (ErrorStepID.contains("CallActivity")) 
    {
		if (monitor.equals("com.sap.xi.mapping.camel.XiMappingException")) 
		{
			exceptionBody = 'Mapping Error Detected \nException Caught: ' + ExceptionMoniter;
			message.setHeader('Mailto', DataErrorTo);
			message.setHeader('ErrorDetails', exceptionBody);
		}
		else if (dataConversionExceptions.contains(monitor)) {
            exceptionBody = 'Data Conversion Failure: \nException Caught: ' + ExceptionMoniter;
            message.setHeader('Mailto', DataErrorTo);
            message.setHeader('ErrorDetails', exceptionBody);
        } else {
            exceptionBody = 'Data Error Occured: \nException Caught: ' + ExceptionMoniter;
            message.setHeader('Mailto', DataErrorTo);
            message.setHeader('ErrorDetails', exceptionBody);
        }
    }
    else if (ErrorStepID.contains("EndEvent")) {
        exceptionBody = 'Data Error Occured: \nException Caught: ' + ExceptionMoniter;
        message.setHeader('Mailto', DataErrorTo);
        message.setHeader('ErrorDetails', exceptionBody);
    }
    else if (ErrorStepID.contains("MessageFlow")) {
		if (ResponseCode == 500) {
			exceptionBody = 'Connection Error due to Internal Server: \nException Caught: ' + ExceptionMoniter;
			message.setHeader('Mailto', ConnectionErrorTo);
			message.setHeader('ErrorDetails', exceptionBody);
		}
		else if (ResponseCode == 401) {
			exceptionBody = 'Connection Error due to UnAuthorized Access: \nException Caught: ' + ExceptionMoniter;
			message.setHeader('Mailto', ConnectionErrorTo);
			message.setHeader('ErrorDetails', exceptionBody);
		}
		else if (ResponseCode == 400) {
			exceptionBody = 'Data Error due to Incorrect Data or Invalid Data Format: \nException Caught: ' + ExceptionMoniter;
			message.setHeader('Mailto', DataErrorTo);
			message.setHeader('ErrorDetails', exceptionBody);
		}
		else if (ResponseCode == 404) {
			exceptionBody = 'Data Error due to Resource Not Found/Invalid URL: \nException Caught: ' + ExceptionMoniter;
			message.setHeader('Mailto', DataErrorTo);
			message.setHeader('ErrorDetails', exceptionBody);
		}
		else {
			exceptionBody = 'Connection Error Occured: \nException Caught: ' + ExceptionMoniter;
			message.setHeader('Mailto', ConnectionErrorTo);
			message.setHeader('ErrorDetails', exceptionBody);
		}
    }
    return message;
}