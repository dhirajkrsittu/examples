package com.test

import java.text.SimpleDateFormat

class Index {
    static def getUNIXDate(String xmlDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
        Date date = sdf.parse(xmlDate)
        long res = date.getTime()
        println(res)
        return res
    }

    static def getUNIXTime(String xmlDate) {
        String[] array = xmlDate.split("T")
        String time = array[1]
        String[] timeArray = time.split(":")
        String res = sprintf("PT%sH%sM%sS", timeArray[0], timeArray[1], timeArray[2])
        println(res)
        return res
    }

    static def getTimeWithTZ(String xmlDateWithTZ) {
        String inputTime = xmlDateWithTZ.replace("T", " ")
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        Date date = sdf.parse(inputTime)
        long res = date.getTime()

        String[] array = xmlDateWithTZ.split("\\+") // ["2023-09-08T15:23:34", "02:30"]
        String timeDiff = array[1] // 02:00
        String[] timeDiffArr = timeDiff.split(":") // ["02", "00"]
        int diffHour = timeDiffArr[0].toInteger() // 2
        int diffMin = timeDiffArr[1].toInteger() // 0
        long diff = ((diffHour * 60) + diffMin) * 60 * 1000 // conversion to milliseconds

        long newEpochTime = res + diff
        Date newDate = new Date(newEpochTime) // creating new date object with new epoch time
        String newTS = sdf.format(newDate)
        println(newTS.replace(" ", "T"))
    }

    static void main(String[] args) {
        String testInput = "2023-09-08T23:23:34+05:30"
        getTimeWithTZ(testInput)
    }
}
