/*
Author: Sonali Prakash
Date: 21-Aug-2023
Version: 1.0

This groovy is to log the payload in CPI based on the flag.
*/


import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;


def Message inputXML(Message msg) {
    //Body
    def body = message.getBody(String);
    
    def properties = message.getProperties();
    def logPayload = properties.get("LogInputPayload");
    
    def msgLog = messageLogFactory.getMessageLog(message);
    if(msgLog!=null && logPayload.toLowerCase().equals("yes")) 
    {
        msgLog.addAttachmentAsString("InputPayload",body,"text/plain");
    }

    return msg;
}

def Message AfterMappingPayload(Message msg) {
    //Body
    def body = message.getBody(String);
    
    def properties = message.getProperties();
    def logPayload = properties.get("LogAMPayload");
    
    def msgLog = messageLogFactory.getMessageLog(message);
    if(msgLog!=null && logPayload.toLowerCase().equals("yes")) 
    {
        msgLog.addAttachmentAsString("After Mapping Payload",body,"text/plain");
    }

    return msg;
}

def Message ResponsePayload(Message msg) {
    //Body
    def body = message.getBody(String);
    
    def properties = message.getProperties();
    def logPayload = properties.get("ResponsePayload");
    
    def msgLog = messageLogFactory.getMessageLog(message);
    if(msgLog!=null && logPayload.toLowerCase().equals("yes")) 
    {
        msgLog.addAttachmentAsString("SO Response",body,"text/plain");
    }

    return msg;
}


def Message processData(Message message) {
    //Body 
    def messageLog = messageLogFactory.getMessageLog(message);
    
    if(messageLog != null)
    {
        def properties = message.getProperties();
		
        def PurchaseOrderByCustomer = properties.get("PurchaseOrderByCustomer");
	    messageLog.addCustomHeaderProperty("PurchaseOrderByCustomer", PurchaseOrderByCustomer);			
	}
	return message;
}

def Message logSalesOrderCreated(Message message) {
    //Body 
    def messageLog = messageLogFactory.getMessageLog(message);
    
    if(messageLog != null)
    {
        def properties = message.getProperties();
        def SalesOrder = properties.get("SalesOrder");
	    messageLog.addCustomHeaderProperty("SalesOrder", SalesOrder);		
	}
	return message;
}