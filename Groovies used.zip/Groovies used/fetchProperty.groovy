/*
Author: Sonali Prakash
Date: 09-Sept-2023
Version: 1.0

This groovy is to fetch the properties from content modifier to use it in message mapping.
*/

import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.mapping.MappingContext

//Fetch Notification Type Property
def String getPropertyNotifType(String setNotifType, MappingContext context)
{
	def propValue1 = context.getProperty(setNotifType)
	return propValue1; 
}

//Fetch Funtional Location Property
def String getPropertyFLOC(String existingFLOC, MappingContext context)
{
	def propValue2 = context.getProperty(existingFLOC)
	return propValue2; 
}

//Fetch Processing Context Property
def String getPropertyProcessingContext(String setProcessingContext, MappingContext context)
{
	def propValue3 = context.getProperty(setProcessingContext)
	return propValue3; 
}

//Fetch Work Center Property
def String getPropertyWC(String NewWorkCenter, MappingContext context)
{
	def propValue4 = context.getProperty(NewWorkCenter)
	return propValue4; 
}


//Fetch WorkMaintenance Planner Property
def String getPropertyPlannerGrp(String getCodeOUT, MappingContext context)
{
	def propValue5 = context.getProperty(getCodeOUT)
	return propValue5; 
}

//Fetch LongText Property
def String getPropertyLongtext(String setLongtext, MappingContext context)
{
	def propValue = context.getProperty(setLongtext)
	return propValue; 
}

//Fetch EmployeeNumber 
def String getPropertyEmpNr(String setEmpNr, MappingContext context)
{
	def propValue = context.getProperty(setEmpNr)
	return propValue; 
}