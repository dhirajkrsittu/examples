/*
Author: Sonali Prakash
Date: 16-Oct-2023
Version: 1.0

This groovy is to log the payload in CPI.
*/

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

//Logging the API response 
def Message InputPayload(Message msg) {
   
    def body = msg.getBody(java.lang.String) as String;
    
    def propertyMap = msg.getProperties(); 
    def PayloadLog = propertyMap.get("PayloadLog");     //Read logger from the Message Properties   
    
    def messageLog = messageLogFactory.getMessageLog(msg);
    if(PayloadLog.equalsIgnoreCase("Y") && messageLog != null ) 
    {    
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("S4 API response Payload ", body, "text/plain");  
    }
    return msg;
}

//Post doing the mapping transformation of API response 
def Message AfterMappingPayload(Message msg) {
   
    def body = msg.getBody(java.lang.String) as String;
    
    def propertyMap = msg.getProperties(); 
    def PayloadLog = propertyMap.get("PayloadLog");     //Read logger from the Message Properties   
    
    def messageLog = messageLogFactory.getMessageLog(msg);
    if(PayloadLog.equalsIgnoreCase("Y") && messageLog != null ) 
    {    
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("After Mapping Payload ", body, "text/plain"); 
    }
    return msg;
}

//Log the CSV converted data after the mapping step
def Message CSVconvertedPayload(Message msg) {
       
    def body = msg.getBody(java.lang.String) as String;
    
    def propertyMap = msg.getProperties(); 
    def PayloadLog = propertyMap.get("PayloadLog");     //Read logger from the Message Properties   
    
    def messageLog = messageLogFactory.getMessageLog(msg);
    if(PayloadLog.equalsIgnoreCase("Y") && messageLog != null ) 
    {    
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("CSV converted Payload ", body, "text/plain"); 
    }
    return msg;
}

//Final payload sent to FIELDGLASS
def Message TargetPayload(Message msg) {
   
    def body = msg.getBody(java.lang.String) as String;
    
    def propertyMap = msg.getProperties(); 
    def PayloadLog = propertyMap.get("PayloadLog");     //Read logger from the Message Properties   
    
    def messageLog = messageLogFactory.getMessageLog(msg);
    if(PayloadLog.equalsIgnoreCase("Y") && messageLog != null ) 
    {    
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Target Payload ", body, "text/plain");  
    }
    return msg;
}
