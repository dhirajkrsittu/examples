import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.commons.text.StringEscapeUtils

def Message processData(Message message) {
    // Get the body as a string
    def body = message.getBody(String) as String
    
    // Decode HTML entities
    def decodedBody = StringEscapeUtils.unescapeHtml4(body)
    
    // Set the modified body back to the message
    message.setBody(decodedBody)
    
    return message
}