import groovy.xml.*
import com.sap.gateway.ip.core.customdev.util.Message


  def Message processData(Message message) {

    def body = message.getBody(java.lang.String)
    def mainPayload = message.getProperty("xmlPayload")
    def ODataResponse = new XmlSlurper().parseText(body)
    def OData = ODataResponse.MeasuringPointType
    def payload = new XmlSlurper().parseText(mainPayload)
    def measuringLiquid = payload.MeasuringLiquid
    def output = new StringWriter()
    def xmlOutput = new MarkupBuilder(output)
    xmlOutput.root {
        MeasuringLiquid {
            MeasuringPoint(measuringLiquid.MeasuringPoint)
            MeasuringDate(measuringLiquid.MeasuringDate)
            MeasuringTime(measuringLiquid.MeasuringTime)
            MeasuringValue(measuringLiquid.MeasuringValue)
            MeasUoM(OData.CharcValueUnit)
        }
    }
    def finalResponse = output.toString()
    message.setBody(finalResponse)
 
    return message;

}


 def Message CountRecords(Message message) {
     
     def messageLog = messageLogFactory.getMessageLog(message);
	def map  = message.getProperties();
    def MeasuringDate   = map.get("MeasuringDate");
    def MeasuringTime = map.get("MeasuringTime");
    def  MeasuringDateTime = MeasuringDate+" "+MeasuringTime
     
    message.setProperty("RecordNumber", ((message.getProperty("CamelSplitIndex"))+1).toString())
     message.setProperty("MeasuringDateTime",MeasuringDateTime)
    return message;

}